Execute with:

cd Assgn1-CS21BTECH11001
gcc Assgn1Src-CS21BTECH11001.c -lrt -pthread -lm 
./a.out

Information about the contents of zipfile:
  - Assgn1Src-CS21BTECH11001.c contains the source code. 
  - Assgn1Report-CS21BTECH11001.pdf contains the report, which was generated from Assgn1Report-CS21BTECH11001.tex
  - Assgn1Readme-CS21BTECH11001.txt is this file, which contains execution commands and miscellaneous information. 
  - logs is the directory into which the program writes the process-specific logfiles.
  - OutMain.txt contains the perfect numbers less than n, grouped by generating process.
  - InMain.txt is the input file used for testing. 

