The program can be executed using the following command

g++ Assgn1_Src_CS21BTECH11001.cpp -pthread -lm && ./a.out

The result will be stored in output.txt. No output to the terminal.