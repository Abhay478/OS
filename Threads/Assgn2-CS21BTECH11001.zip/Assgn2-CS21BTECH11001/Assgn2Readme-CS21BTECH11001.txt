Execute with:

cd Assgn2-CS21BTECH11001
gcc Assgn2Src-CS21BTECH11001.c -lrt -pthread -lm
./a.out

Information about the contents of zipfile:
  - Assgn2Src-CS21BTECH11001.c contains the source code. 
  - Assgn2Report-CS21BTECH11001.pdf contains the report, which was generated from Assgn2Report-CS21BTECH11001.tex
  - Assgn2Readme-CS21BTECH11001.txt is this file, which contains execution commands and miscellaneous information. 
  - logs is the directory into which the program writes the process-specific logfiles.
  - OutMain.txt contains the perfect numbers less than n, grouped by generating thread.

