#include "types.h"
#include "user.h"
// #include "defs.h"

// int glob[10000];
int main() {
    // printf(1, "?\n");
    // int loc[10000];
    int * loc = (int *)malloc(40000);
    for(int i = 0; i < 100; i++){
        printf(1, "%d", loc[i]);
    }
    printf(1, "\n");
    int c = pgt();

    printf(1, "%d\n", c);
    exit();
}